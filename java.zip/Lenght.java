import java.util.Scanner;

class Lenght{
    public static void main(String[] args){
    Scanner sc=new Scanner(System.in);
    System.out.println("enter the character");
    String var=sc.next();
    int Lenght=var.length();
    System.out.println("the lenght of character is :" + Lenght);
    }
}
