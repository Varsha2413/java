class Car1 {
    private String ModelName;
    private String owner;
    private int regNumber;

    public Car1(String ModelName,String owner,int regNumber)
    {
        this.ModelName = ModelName;
        this.owner=owner;
        this.regNumber=regNumber;
    }
    public void startEngine(){
        System.out.println("engin can be started..");
        
    }
    public void accelerate(){
        System.out.println("car can be accrelerated..");
    }
    public void stop(){
        System.out.println("car can be stopped..");
    }
    public void showCarinformation(){
        System.out.println("car can be be owned by"+ owner);
        System.out.println("car model is"+ ModelName);
        System.out.println("the regNumber is"+ regNumber);
    }
    public static void main(String[] var0){
        Car1 myCar= new Car1 ("Suzuki","xyz",123);
        myCar.startEngine();
        myCar.accelerate();
        myCar.stop();

        myCar.showCarinformation();
    }
}

    

