

class Bird {
    void fly(){
        System.out.println("Bird can fly");

    }
} 
class Parrot extends Bird{
    void color(){
        System.out.println("i am green");
        }
}
class SingleParrot extends Parrot{
    void sing(){
        System.out.println("i can sing");
    }
}
class cow extends Bird{
    void whatcoloriam(){
        System.out.println("i am  black");
    }
}
public class Main
{
    public static void main(String[] args){
        SingleParrot p =new SingleParrot();
        cow s = new cow();
        s.whatcoloriam();
        p.sing();
        p.color();
        p.fly();
        p.fly();

    }
}
package demo;
 public class HybridInheritance{
    public static void main(String[] args){
        D obj = new D();
        obj.Display();

    }
 }
//multiple inheritance
class A{
    int a=1;
}
class B extends A{
    int b=2;
}
//interface
interface c{
    int c=3;
}

//extend and implimentation together
class D extends B implements c{
    int d=4;
    int sum = a + b + c + d;

    public void Display(){
        System.out.println("the value of a is "+ a);
        System.out.println("the value of a is "+ b);
        System.out.println("the value of a is "+ c.c);
        System.out.println("the value of a is "+ d);
        System.out.println("the sum is "+ sum);
        
    }
}