import java.util.Scanner;

class Calulator{
    public static void main(String[] args){
        Scanner sc= new Scanner(System.in);
        int a,b,result;
        System.out.println("please enter any two number=");
        a=sc.nextInt();
        b=sc.nextInt();
        System.out.println("enter ur choice");
        int operator=sc.nextInt();
        switch(operator)
        {
            case 1:
                result=a+b;
                System.out.println("result:" + result );
                break;
            case 2:
                result=a-b;
                System.out.println("result:" + result );
                break;
            case 3:
                result=a*b;
                System.out.println("result:" + result ); 
                break;
            case 4:
                result=a/b;
                System.out.println("result:" + result );
                break;
            default:
                System.out.println("u entered invalid choice");
                return;
        }
    }
}