class Animal{
    public void sound(){
        System.out.println("animal male sound");
    }
}
class dog extends Animal{
    //subclass method override the super class method
    public void sound(){
        System.out.println("the dog can break");
    }
}
class cat extends Animal{
    public void sound(){
        System.out.println("the cat moves");
    }
}
public class Override{
    public static void main(String[] args){
    Animal myAnimal = new Animal();
    Animal mydog = new dog();
    Animal mycat = new cat();
    
    myAnimal.sound();
    mydog.sound();
    mycat.sound();
}
}