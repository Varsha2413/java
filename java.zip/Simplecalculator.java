 import java.util.Scanner;

public class Simplecalculator{
    public static void main(String[] args){
        int a,b,temp;
        Scanner sc= new Scanner(System.in);
        System.out.println("enter the 1st no");
        a = sc.nextInt();
        System.out.println("enter the 2nd no");
        b = sc.nextInt();
        
        
        temp = a;
        a = b;
        b=temp;
        System.out.println("after swapping");
        System.out.println("a :"+ a);
        System.out.println("b :"+ b);
        

    }
}