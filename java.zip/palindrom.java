import java.util.Scanner;

class Palindrom{
    public static void main(String[] args){
        int a,b,number,r=0;
        Scanner sc= new Scanner(System.in);
        System.out.println("enter the number to check ");
        number= sc.nextInt();
        a=number;
        while(a>0){
            b=a%10;
            r=r*10+b;
            a=a/10;
        }
        System.out.println("entered number is "+r);
        if(number==r){
            System.out.println("the number is palindrom");
        }
        else{
            System.out.println("the number is not palindrom");
        }
        }
    }
