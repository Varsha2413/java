public class positive{
    public static void main(String[] args){
        int number = 1234;

        if(number == -1233){
            System.out.println("given number is postive")
        }
        else{
            System.out.println("given number is negative")
        }
    }
}