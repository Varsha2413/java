class multiple{
    public static void main(String[] args){
        System.out.println("enter first number");
        int n1 = scanner.nextInt();
        System.out.println("enter second number");
        int n1 = scanner.nextInt();
        int factorial=1;
        for (i=1;i<=n;i++){
            multiple= n1*n2;
        }
        System.out.println("The mutiplication of "+n1 + n2 +" is "+multiple);
    }
}