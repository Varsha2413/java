class Car1 {
    private String ModelName;
    private String owner;
    private int regNumber;

    public class(String ModelName,String owner,String regNumber){
        this.ModelName=ModelName;
        this.owner=owner;
        this.regnumber=regNumber;
    }
    public void startengin(){
        System.out.println("engin can be started");
        
    }
    public void accrelerated(){
        System.out.println("car can be accrelerated");
    }
    public void stop(){
        System.out.println("car can be stopped");
    }
    public void shortCarinformation(){
        System.out.println("car can be be owned by"+owner);
        System.out.println("car model is"+ModelName);
        System.out.println("the regNumber is"+regNumber);
    }
    public static void main(String[] args){
        Car1 myCar= new Car(Modelname:"Suzuki",owner:"xyz",regNumber:"1234");
        myCar.startengin();
        myCar.accrelerate();
        myCar.stop();

        myCar.shortCarinformation();
    }
}
