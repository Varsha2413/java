 public class MultiplecatchBlockExample{
    public static void main(String[] args){
        try{
            int arr[] = new int[5];
            arr[5] = 30/1;
        }catch(ArithmeticException e){
            System.out.println("ArithmeticException divisible by zero");
        }catch(ArrayIndexOutOfBoundsException e){
            System.out.println("ArrayIndexOutOfBoundException: array index out of bond");
        }finally{
            System.out.println("Exception some other exception occured");
        }
        
        
 }
 }