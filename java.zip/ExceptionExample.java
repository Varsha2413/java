 public class ExceptionExample{
    public static void main(String[] args){
        try{
            //risky code that may handel cause an exceptions
            int a = 10/0;//this will throw arthimatic exception
            System.out.println("Result:"+a);
        }catch(ArithmeticException e){
            System.out.println("error Division by zero");
        }finally{ 
            //cpde that always executed
            System.out.println("this is finally block");
        }
        System.out.println("rest of the code....!");
    }
 }